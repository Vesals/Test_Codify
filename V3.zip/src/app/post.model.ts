export interface Post {
    data: any[];
    // Add other backend response properties here if present
}

// export interface Post {
//     fName: string;
//     lName: string;
//     email: string;
//     // ...
// }
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfileDetailComponent } from './profile-detail/profile-detail.component';
import { ProfileComponent } from './profile.component';

const routes: Routes = [
  // { 
  //   path: 'profile-detail', 
  //   component: ProfileDetailComponent
  // },
  {
    path: '', pathMatch: 'full', redirectTo: 'profile'

  },
  { 
    path: 'profile', 
    component: ProfileComponent,
  },

  {
    path: 'profile-detail',
    component: ProfileDetailComponent
 },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileRoutingModule { }
